sudo java -jar FindRepe.jar --install-version

